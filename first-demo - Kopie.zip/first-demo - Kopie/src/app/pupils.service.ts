import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PupilsService {

  pupilNames = ['Max', 'Eva', 'Hans', 'Franz'];

  constructor() { }

  getPupilNames(): string[]{
    return this.pupilNames;
  }
}
