import { Component, OnInit } from '@angular/core';
import { PupilsService } from '../pupils.service';

@Component({
  selector: 'app-pupils',
  templateUrl: './pupils.component.html',
  styleUrls: ['./pupils.component.css']
})
export class PupilsComponent implements OnInit {
  title = 'Pupilsdemo';
  pupilNames: string[];

  constructor(pupilsService: PupilsService) {
      this.pupilNames = pupilsService.getPupilNames();
   }

  ngOnInit() : void {
  }

}
