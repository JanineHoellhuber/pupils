import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Sensor } from 'src/sensor';
// import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-measurement-input',
  templateUrl: './measurement-input.component.html',
  styleUrls: ['./measurement-input.component.css']
})
export class MeasurementInputComponent implements OnInit {

  @Input() 
  sensorvalues: Sensor[]; //= [new Sensor(1,'Office Temperature','ppm')];

 /* @Input() values: number;
  @Input() sensornames: string;*/
  @Input() units: string;
  /*@Input() sensorname =['Office Temperature','Office Humidity', 'co2'];
  @Input() value = [1,2,3];*/
  @Input() unit = ['°C', 'ppm', '%'];

  /*@Output() valueChange = new EventEmitter<number>();*/
  @Output() unitChange = new EventEmitter<string>();
  /*@Output() sensornameChange = new EventEmitter<string>();*/


  constructor() { }

  ngOnInit(): void {
  }

  /*onValueChanged(): void{
    this.valueChange.emit(this.values);
  }*/
  onUnitChanged(): void{
    this.unitChange.emit(this.units);
  }
  /*onSensorNameChanged(): void{
    this.sensornameChange.emit(this.sensornames);
  }*/
}
