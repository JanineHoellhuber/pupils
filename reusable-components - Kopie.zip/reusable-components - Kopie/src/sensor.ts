export class Sensor {
   
     value: number;
     sensorname: string ;
     units: string;
        
     constructor(value, sensorname, units){
        this.value = value;
        this.sensorname = sensorname;
        this.units = units;
        

       
    }
}